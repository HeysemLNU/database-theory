The application has been built into  a jar file. You'll need java 10 or more.

you can also run the source code included in the src folder

The diagrams and other information can be found in the report file

the program  needs the following arguments by order
<host> <port> <username> <password> <nameofdatabase>
 
A last mention is that initialising a connection for each query and disconnecting from the database for each query is a design choice.
